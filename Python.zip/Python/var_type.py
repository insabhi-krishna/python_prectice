a = 2.6
b = "hello"
c = 89
d = True

print(type(a))
print(type(b))
print(type(c))
print(type(d))
# web can can know data type with this python fumction 