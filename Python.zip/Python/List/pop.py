list5 = ["jerry", "hello", "hii", "welcome"]
# pop() funtion use for remove any list value by indexing value
list5.pop(2)
print(list5)