em = []

em.append("a")
em.append("b")
em.append("c")
print(em)
em.remove("b")
print(em)