# Q. Converting a tuple to a list:

tuple_to_list = list((1,2,3))
print(tuple_to_list)