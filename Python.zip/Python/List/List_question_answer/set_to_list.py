# Q.Converting a set to a list:

set_to_list = list({4,5,6})
print(set_to_list)