
# Q. Converting a string to a list:
str_to_list = list("Krishna") 
print(str_to_list)