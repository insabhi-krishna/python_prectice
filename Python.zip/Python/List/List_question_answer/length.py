#  Q. How do you find the length of a list?

list1= ["Hii", "This", "Python", "Class"]

list2 = len(list1)
print(list2)