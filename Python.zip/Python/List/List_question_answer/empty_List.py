# Q.Creating an empty list:

list1 = ["a" ,"b" ,"c"]

list1.clear()
print(list1)