# Q. How do you remove a specific element from a list by its value?

list1 = ["Apple", "banana", "orange"]

list1.remove("banana")
print(list1)