# Q. How do you slice a list to get a sublist?
list1 = [1,2,3,4,5,6]
list2 = list1[1:5]
print(list2)