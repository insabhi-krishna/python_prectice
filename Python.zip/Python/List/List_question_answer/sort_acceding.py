# Q. How do you sort a list in ascending order?

list1 = ["c" , "b", "a", "d", "e"]

list1.sort()
print(list1)