# Q. How can you access the first element of a list?

list1 = ["Apple" , "Hello", "banana", "orange"]
print(list1[0])