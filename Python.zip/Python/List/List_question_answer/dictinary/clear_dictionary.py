dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}
# The del keyword can also delete the dictionary completely:
dict1.clear()
print(dict1)