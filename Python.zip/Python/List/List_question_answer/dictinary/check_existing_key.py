dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}

if "email" in dict1:
    {
        print("emial alerady exist in list")
    }