dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}

a = dict1.keys()
print = a