dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}
# The popitem() method removes the last inserted item
dict1.popitem()
print(dict1)