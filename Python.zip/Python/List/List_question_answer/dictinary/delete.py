dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}
# The del keyword removes the item with the specified key name:
del dict1["email"]
print(dict1)