dict = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}

print(dict)