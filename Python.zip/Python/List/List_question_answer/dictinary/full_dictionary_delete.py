dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}
# The del keyword can also delete the dictionary completely:
del dict1
print(dict1)