dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}

dict1["name"] = "krishna"
print(dict1)