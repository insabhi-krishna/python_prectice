dict1 = {
    "name" :"John",
    "number" : 7031987337,
    "email" : "john@gmail.com",
    "address" : "pandaveswar"

}
# The pop() method removes the item with the specified key name:
dict1.pop("address")
print(dict1)