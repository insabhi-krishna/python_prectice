# Q. How do you check if an item exists in a list?

list1 = ["a", "b", "c", "d", "e"]

print("d" in list1)

if "d" in list1:
    print("hii amaze")