# Q. How do you reverse a list?

list1 = [1,2,3,4,5,6]
list1.reverse()
print(list1)