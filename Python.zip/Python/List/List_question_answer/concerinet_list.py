# Q. How can you concatenate two lists in Python?

list1 = [1,2,3]
list2 = [4,5,6]
list3 = list1 + list2
print(list3)