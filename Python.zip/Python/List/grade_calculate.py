# Write a Python program to convert a student's percentage score into a letter grade (A, B, C, D, or F) based on the following criteria:

# A: 90-100
# B: 80-89
# C: 70-79
# D: 60-69
# F: Below 60

math = int(input("Enter math subject number:"))
english = int(input("Enter english subject number:"))
hindi = int(input("Enter hindi subject number:"))
history = int(input("Enter history subject number:"))
geography = int(input("Enter geography subject number:"))

total = math + english + hindi + history + geography

avg = total/5

print("Total Marks Of Student:", total)
print("Total Percentage Of Student:", avg)

if avg >= 100:
    print("Your Grade is: A")

elif avg >= 80:
    print("Your Grade is: B")
elif avg >= 60:
    print("Your grad is : C")
elif avg>=40:
    print("Your grade is : D")
else:
    print("your are fails")