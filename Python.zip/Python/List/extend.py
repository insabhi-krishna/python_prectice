cricket = ["virat" , "Dhoni" , "suresh" , "Bumrah"]
actor = ["Hrithik" , "Sarukh" , "Amir"]
# To simplay print together  elements from another list to the current list, use the extend() method.
cricket.extend(actor)
print(cricket)

actor.extend(cricket)
print(actor)