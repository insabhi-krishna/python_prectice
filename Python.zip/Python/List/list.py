list1 = ["aksh" , "Abhinash", "Roshan" , "Neha"]

print(list1[2])
# print listing from list 
print(list1[1:3])
#  we can print last value  from list 
print(list1[-2])

# print from last value list
print(list1[-3:-1])

# To determine if a specified item is present in a list use the in keyword:
# Check if "Neha" is present in the list:
 
if "Neha" in list1:
 print("Welcome to Neha Dashboard")
 
else:
    print("Sorry You Are Not In List")