list5 = ["jerry", "hello", "hii", "welcome"]
# del() funtion use for delete any list value by indexing value
#  we can also delete entir list variable using del() funcion
del list5[3]
print(list5)