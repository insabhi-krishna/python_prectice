empolyee = ["krishna", "raja" , "srinath"]
# remove  function delete  any value in the list variable
empolyee.remove("raja")
print(empolyee)