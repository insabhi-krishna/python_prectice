short = ["B","D","E","A","C","F","G"]
# copy() function use copy data from  a variable  to anathor
duplicate = short.copy()
print(short)
print(duplicate)