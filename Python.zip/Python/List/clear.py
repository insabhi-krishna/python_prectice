list5 = ["jerry", "hello", "hii", "welcome"]
# clear() funtion use for clear list value
list5.clear()
print(list5)