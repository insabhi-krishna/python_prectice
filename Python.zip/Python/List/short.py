short = ["B","D","E","A","C","F","G"]
# List objects have a sort() method that will sort the list alphanumerically, ascending, by default:
short.sort()
print(short)