join_1 = ["A","B", "c"]
join_2 = ["D","E", "F"]

join_3 = join_1.append(join_2)
# join_3 = join_1 + join_2

print("This Is join Two List Values :",join_3)