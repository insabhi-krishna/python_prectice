list3 = ["Php" , "C" , "Java" , "python"]

list3.insert(2, "java script")
print(list3)