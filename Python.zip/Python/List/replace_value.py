list2 = ["Lion" , "Tiger" , "Dog" , "Bull"]
# To change the value of a specific item, refer to the index number:

list2[1] = "Leo"
print(list2)

# Change the values "Dog" and "Bull" with the values "blackcurrant" and "watermelon":

list2[2:4] = ["Goat" , "Cow"]
print(list2)