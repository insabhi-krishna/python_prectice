empolyee = ["krishna", "raja" , "srinath"]
# Append function add any value in the list variable after last value
empolyee.append("Sachin")
print(empolyee)