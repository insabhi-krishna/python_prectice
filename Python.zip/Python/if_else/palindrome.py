# Write a Python program to check if a given string is a palindrome (reads the same forwards and backwards).

word = str(input("Enter the Word: "))

if word == word[::-1]:
    print(f"{word} This is a palindrom Word")

else:
    print(f"{word} This is a notpalindrom word")
