# Write a Python program that takes the age of a user and checks if they are eligible to vote (must be 18 or older).

voting_age = int(input("Enter the candidate Age :"))

if voting_age >=18:
  print("Hii! Your are Eligable For Voting",voting_age)
else:
  print("Sorry You are Not Eligibale For Voting")
