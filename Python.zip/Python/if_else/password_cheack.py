# Write a Python program to check if a password entered by a user is strong enough (length ≥ 8 and contains numbers and letters).
password = input("Enter Your Password: ")

if len(password) >= 8 and any(char.isdigit for char in password) and any(char.isalpha() for char in password) and any(char.islower() for char in password) and any(char.isupper() for char in password):
    print("Password is strong")
else:
    print("Your Password is Too Week")