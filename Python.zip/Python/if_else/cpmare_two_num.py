# Compare Two Numbers

num1 = int(input("Enter First Number:"))
num2 = int(input("Enter Seconf Number:"))

if num1 > num2:
    print(num1,"Frist Number is grater than Second Number")
elif num1==num2:
    print("Frist and Second Number Equal")
else:
    print(num1, "Fisrt Number is Not Greater than Second Number")