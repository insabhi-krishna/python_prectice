# WAP to print "" in print("")

print('""')

print("\"\"")
