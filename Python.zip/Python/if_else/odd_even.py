# Check Even or Odd
num = int(input("Enter Number:"))

if num % 2 ==0:
    print(num,"This is even Number")
else:
    print(num, "This is odd Number")
