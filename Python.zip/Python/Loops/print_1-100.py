# print 1 to 100 count using while loop

i = 1

while i<=10:
    print(i)
    i += 1