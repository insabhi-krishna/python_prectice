nums = [1,2,3,4,5,6,7,8,9]
fruits = ["apple","banana","orange","lichi"]

indx = 0

while indx < len(nums):
    print(nums[indx])
    indx+=1


f = 0
while f < len(fruits):
    print(fruits[f])
    f+=1