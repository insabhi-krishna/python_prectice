# To print the square of each non-negative integer that is less than n = 3, you can loop through the list [0, 1, 2] and print the square of each number on a separate line.

n = int(input("Enter Number: "))
for i in range(n):
        print(i**2)