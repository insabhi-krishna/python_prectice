table = int(input("Enter the Number:"))

i = 1
while i <=10:
    print(table*i)
    i += 1
