# iteratior
i =1

# Stoping point
while i>=10: 
    print(i)
    i-=1