a = int(input("Enter the first number:"))
b = int(input("Enter the first number:"))
c = int(input("Enter the first number:"))
d = int(input("Enter the first number:"))

sum = (a+b+c+d)
print("Total marks:",sum)
avg = sum/4
print("percentage:",avg)

if avg>=60:
    print("First Division")
elif avg>=45:
    print("second division")
elif avg>=30:
    print("Pass")
else:
    print("fail")
    
