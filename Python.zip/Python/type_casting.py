x = 35.20

print(int(x)) 
# type casting change data type example : I assign a variable with float value but in print time convert there data type into intiger