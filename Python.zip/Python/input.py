a = int(input("Enter the First Numbe:"))
b = int(input("Enter the Second Number:"))
add = (a + b)
print("Sum of Two Number:",add)