a= "welcome to"
b = "Insabhi"
print(a,b)
print(len(b))