range_count = "Welcome  to our world"
res = range_count.range(0, 5)
print(res)