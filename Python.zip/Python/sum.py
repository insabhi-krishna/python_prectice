a = 45
b = 87

sum = (a + b)
print("Sum of two Number:", sum)

