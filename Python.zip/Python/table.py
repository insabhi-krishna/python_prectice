for x in range(11):
    print(x*2)
