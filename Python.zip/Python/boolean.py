a = 50
b = 90

if a > b :
    print("A is greater than B :", a)
else:
    print("B is greatet than A", b)