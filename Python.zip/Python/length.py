length_count =str(input("Write Something:"))
len_str = len(length_count)

print(len_str)

# if length_count >= len_str:
#     print("your are a valid user :")
# else:
#     print("Sorry Not a user!")